<?php
$lang['BUT_VAL']="Login to Post Comment";
$lang['BUT_VAL1']="Post Comment";
$lang['COM_ON']="Comment on";
$lang['UR_COMM']='Your Comment';
?>