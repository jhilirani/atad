<?php
$lang['INV_SEND_SUCCESS']="Invoice sent successfully";
$lang['INV_FILE_TYPE_ERR']="Invalid file for invoice! Please try again";
$lang['INV_FILE_SIZE_ERR']="Size of invoice file is above maximum limit! Please try again.";
$lang['UNKNOWN_ERROR_TO_MOVE_THE_FILE']="Unknown error stops file submission!";
$lang['UNKNOWN_ERR_TO_S_INV']="Unknown error stops file submission!";
?>