<?php
$lang['LOGIN_SUCCESS_MSG']="You have successfully logged in";
$lang['LOGIN_FAIL_MSG']="Login failed. Please try again.";
?>