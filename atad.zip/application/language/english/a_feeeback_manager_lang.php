<?php
$lang['SUCC']="Feedback for sponsor posted successfully";
$lang['FAIL']="Feedback already sent to the selected sponsor";
?>