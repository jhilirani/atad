<?php
$lang['MSG_CENTER']='Message Center';
$lang['E_PROF']='Edit Profile';
$lang['ACC_SETT']="Account Settings";
$lang['CH_PASS']="Change Password";
$lang['CH_ORG_INFO']='Change Organizational Information';
$lang['CH_BANK_INFO']='Change Bank Information';
?>