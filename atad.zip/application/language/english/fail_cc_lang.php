<?php
$lang['HEADING']="Payment  Cancelled at Authorize.net";
$lang['FAIL_MSG']="You cancelled PayPal payment process";
$lang['FAIL_MSG1']="Therefore all information related to your payment are removed";
$lang['FAIL_MSG2']="Please try again.";
?>