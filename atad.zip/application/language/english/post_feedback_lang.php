<?php
$lang['P_FEEDB_HEAD']="Post a Feedback";
$lang['MANDATORY_MSG1']="All fields which are marked with red star";
$lang['MANDATORY_MSG2']="are mandatory";
$lang['S_EVENT']="Select an event";
$lang['FEED']='Feedback message';
?>