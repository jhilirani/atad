<?php
$lang['TESTM_POST_SUCC']="Thank you.Your testimonial posted successfully!";
?>