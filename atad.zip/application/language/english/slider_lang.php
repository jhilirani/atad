<?php
$lang["PREV"]="Previous";
$lang["PLAY"]="Play";
$lang["PAUSE"]="Pause";
$lang["NEXT"]="Next";
?>