<?php
$lang['QUESTIONARY_SEND_SUCCESS']="Thank you. Your Message has been sent. You will be dully contacted";
?>