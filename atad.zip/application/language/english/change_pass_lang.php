<?php
$lang['CH_UR_PASS']="Change Your Password";
$lang['N_PASS']="New Password";
$lang['CON_PASS']='Confirm Password';
$lang['OL_PASS']="Old Password";
?>