<?php
$lang['PAY_SEND_SUCCESS']="Payment updated successfully";
$lang['INVALID_PAY_DOC_FILE']="Invalid payment document file, payment document file should be .jpg,.png,.jpeg,.pdf";
$lang['PAY_FILE_SIZE_ERR']="Payment file exceeds maximum limit, please reduce file size and try again!";
$lang['UNKNOWN_ERROR_TO_MOVE_THE_FILE']="Unknown error stops file submission!";
$lang['UNKNOWN_ERR_TO_S_PAY']="Unknown error stops file submission!";
?>