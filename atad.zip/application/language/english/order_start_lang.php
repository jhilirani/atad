<?php
$lang['B_P_HEADING']="Billing And Payments Information";
$lang['MANDATORY_MSG1']="All fields which are marked with red star";
$lang['MANDATORY_MSG2']="are mandatory";
$lang['COUNT']="Country";
$lang['STATE']="State/Province";
$lang['CITY']="City";
$lang['ADD']="Street Address";
$lang['ZIP']="Zip Code";
$lang['P_TYPE']='Payment Type';
$lang['SUB']="Submit";
$lang['C_TYPE']="Card Type";
$lang['SEL']='Select';
$lang['C_NO']="Card Number";
$lang['EXP_DT']="Expiry Date";
$lang['CVV']='CVV';
$lang['SP_SPK_DETAIL']='Sponsor Package Details';
$lang['EV_TIT']='Event Title';
$lang['SEL_PKG_NM']='Selected Package Name';
$lang['PKG_CH']='Package Charges';
$lang['B_T']='Bank Transfer';
$lang['B_NM']="Bank Name";
$lang['B_RECEIPT']="Bank Receipt Number";
$lang['B_ADD']="Bank Address";
$lang['B_CD']="Bank Code";
$lang['B_FTC']="Bank Fund Transfer Code";
$lang['BT_MSG']='In case of Bank Transfer, please fill in the details of the transfer and submit.';
?>