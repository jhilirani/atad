<?php
$lang['CMOBJ_HEAD_UP']='Update Your Brand Management Partnership Objective';
?>