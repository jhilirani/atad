<?php
$lang['SUCC']='Measurement objectives created successfully !!';
$lang['SUCC_UP']='Measurement objectives updated successfully !!';
?>