<?php
$lang['INV_ID']="Invalid featured branded spaces identification, please try again";
$lang['DTL']='Space Details';
?>