<?php
$lang["SEARCH"]="Search";
$lang["F_EVENT_N_SPACES"]="Featured Events & Spaces";
$lang["MORE_EVENTS"]="More Events";
$lang["H_I_W"]="How It Works";
$lang["EVENT_GALLERY"]="Events Gallery";
$lang["GUIDE_4_SPONSOR_N_EVNT_ORG"]='Sponsarite Guide';
$lang["BRAND_WE_WORK_WITH"]="Brands we work with";
$lang['S_EMPTY_MSG']='Please enter criteria related to event title';
$lang['F_B_SPACES']='Featured Branded Spaces';
?>