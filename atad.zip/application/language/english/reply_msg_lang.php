<?php
$lang['QUES_REPLY_SUCCESS']='Customer Inquiry replied successfully';
?>