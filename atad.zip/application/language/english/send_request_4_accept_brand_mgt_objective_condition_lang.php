<?php
$lang['SUCC']="Request successfully sent for sponsor brand management objectives!";
?>