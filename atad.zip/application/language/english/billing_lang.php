<?php
if($_SESSION[FE_SESSION_VAR_TYPE]==0){
	/// this is for event organiser
	$lang['UPD_BIL']='Update Billing &amp; Bank Details';
}else{
	/// this is for event organiser
	$lang['UPD_BIL']='Update Billing Details';
}
$lang['BIL_INFO']="Billing Information";
$lang['BANK_INFO']="Bank Information";
$lang['COUNT']="Country";
$lang['STATE']="State/Province";
$lang['CITY']="City";
$lang['ADD']="Street Address";
$lang['ZIP']="Zip Code";

$lang['BANK_NM']='Bank Name';
$lang['BANK_BR']='Bank Branch Name';
$lang['BANK_AC']='Bank Account No';
$lang['BANK_AC_TP']='Bank Account Type';
$lang['ACC_HOLD_NM']='Account Holder Full Name';
?>