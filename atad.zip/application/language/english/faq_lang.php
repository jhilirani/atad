<?php
$lang['FAQ_PAGE_HEAD']='Sponsarite FAQ';
$lang['S_BTN']='Search FAQ Questions';
?>