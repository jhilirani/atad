<?php
$lang['SUCCESS_1']='We have received your payment of ';
$lang['SUCCESS_2']=' Yen by Bank Transfer regarding ';
$lang['SUCCESS_3']=' Sponsorship for ';
$lang['SUCCESS_4']=' More about Invoice and Payment, please go to your dashboard.To get more information on the Event you are sponsoring Please go to ';
$lang['SUCCESS_5']=' Our Event Search Page ';
?>