<?php
$lang['HEADING']="PayPal Payment  Cancelled";
$lang['FAIL_MSG']="You cancelled PayPal payment process";
$lang['FAIL_MSG1']="Therefore all information related the payment have been removed";
$lang['FAIL_MSG2']="Please try again.";?>