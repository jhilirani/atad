<?php 
$lang['SUCC']="Blog comment posted successfully";
?>