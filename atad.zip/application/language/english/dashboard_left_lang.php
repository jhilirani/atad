<?php
$lang['PROF']='Profile';
$lang['UPD_PIC']='Update Photo';
$lang['UPD_PROF']='Preferred Events & Demographics';//Update Profile
$lang['ORG_PRO']='Organisation Profile';
$lang['BILLING']='Billing Details';
$lang['PASS_CH']='Change Password';
?>