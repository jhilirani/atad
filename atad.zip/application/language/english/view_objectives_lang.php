<?php
$lang['OBJ_NM_HEAD']='Brand Partnership Objectives Name';
$lang['VAL_IN']='Value in';
?>