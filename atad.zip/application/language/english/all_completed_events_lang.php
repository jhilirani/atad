<?php
$lang['EVENT_NM']='Event Name';
$lang['CITY']='City';
$lang['STARTED_ON']='Started On';
$lang['END_ON']='Ends On';
$lang['DETAIL']='Details';
$lang['ALL_COMP_EVENTS']="Completed Events";
$lang['UD']='Update';
$lang['No_SEC_EV']='There is no event for this section';
$lang['TURN_OUT']='Expected Turn Out';
$lang['IMG']='Image';
$lang['SH']='Share';
?>