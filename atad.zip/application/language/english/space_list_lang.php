<?php
$lang['HEADING']='Branded Space List';
$lang['SP_TIT']='Title';
$lang['SP_CT']='City';
$lang['SP_DT']='Space Details';
$lang['SP_IMG']='Space Photo';
$lang['SP_V_DT']='View Details';
?>