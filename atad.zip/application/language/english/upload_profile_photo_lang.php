<?php
$lang['UPD_PROF_PHOTO']="Update Profile Photo";
$lang['UPL_N_PH_4_PROF_PIC']="Upload a new profile photo";
?>