<?php
$lang["A_US"]="About Us";
$lang["PRESS"]="Press";
$lang["TESTMON"]="Testimonials";
$lang["T_N_PRIVACY"]='Terms & Privacy';
$lang["S_MEDIA"]='Social Media';
$lang['RIGHT_RESERVE_LINE']='Sponsarite | All Rights Reserved';
$lang['ACCURATELY_MATCH_SPONSORS_WITH_RIGHT_EVENT']='Accurately Match Sponsors with right event';
$lang['CONTACT']='Contact Us';
?>