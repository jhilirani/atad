<?php
$lang['EV_BD']='Event Board';
$lang['CAT']='Categories';
$lang['A_EV']='All Events';
$lang['C_FIL']='Clear Filter';
$lang['SUB_ON']='Submitted on';
$lang['SP']='Sponsor';
$lang['INT']='interested';
$lang['NO_REC']='Sorry, no event found matching your search criteria!';
?>