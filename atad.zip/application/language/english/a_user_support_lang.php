<?php
$lang['SUSS']='Message delivered successfully!<br>Thank you for contacting us. We will be in touch shortly! ';
?>