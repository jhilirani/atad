<?php
$lang['SUCCESS_1']='We have received your payment';
$lang['SUCCESS_2']=' Yen by Bank Transfer regarding ';
$lang['SUCCESS_3']=' Sponsorship for ';
$lang['SUCCESS_4']=' More about Invoice and Payment please visit your dashboard. To get more information on the Event you are sponsoring, please go to ';
$lang['SUCCESS_5']=' Our Event Search Page.';
$lang['SUCCESS_6']=' Your service will be fully activated after getting the payment in our Bank Account.';
?>