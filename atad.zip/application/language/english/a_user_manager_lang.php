<?php 
$lang['PROFILE_UPDATE_SUCCESS_MSG']="Your Profile Modified Successfully";
$lang['BLANK_EMAIL_VALIDATION_MSG']="Blank email address space not accepted, Please write your email ID";
$lang['EMAIL_ALREADY_EXIST_VALIDATION_MSG']="This Email ID already exists. Please enter another email ID.";
$lang['REGISTERATION_SUCC_MSG']="You have been registered successfully.";
$lang['INVALID_PRO_IMG']="Invalid profile image selected!";
$lang['IMG_FILE_SIZE_ERR']='Selected file is too big to upload!';
$lang['UNKNOWN_ERR_2_UPLOAD']="Unknown error arises during file upload";
$lang['EMPTY_2_UPLOAD']="Empty file not allowed";
$lang['PROFILE_IMG_UPDATE_SUCC']="Profile image updated successfully!";
$lang['UR_SESSION_EXPAIR']="Your session has expired!";
$lang['INVALID_OLD_PASS']="Your password is invalid,please try again!";
$lang['ORG_PROF_UPDT_SUCC_MSG']='Organisational profile updated successfully!';
$lang['PASS_UPDT_SUCC_MSG']="Your Password Updated Successfully!";
$lang['BILL_UPDT_SUCC_MSG']="Billing information updated successfully!";
$lang['BILL_BANK_UPDT_SUCC_MSG']="Billing and Banking Information updated successfully!";
?>