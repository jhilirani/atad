<?php
$lang['UPD_PROF']='Update Account Name';
$lang['SEL_CAT_4_EV_RECOM']='Select Category for <br>Event Recommendation'; 
$lang['SEL_AGE_GP_4_EV_RECOM']="Select age group for <br> Event Recommendation"; 
$lang['OF_ATTE_OF_THIS_AGE_GP']='of Attendees of this age group'; 
$lang['MALE_FEMALE_RATIO']="Male to Female Ratio in %";
$lang['MALE_FEMALE_RATIO_MSG']="Enter the male to female ratio should be like[10-90],[ 30-70], or [60-40].<br>So First value is for Male and Second one is for Female.";
?>