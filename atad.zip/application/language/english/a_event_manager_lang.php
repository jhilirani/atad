<?php
$lang['FILE_UPLOAD_BIG_SIZE_ERR']='File too big to upload, Please upload image size less than 2 MB';
$lang['FILE_UPLOAD_UNKNOWN_ERR']='Unknown error arises during file upload !!!';
$lang['FILE_UPLOAD_MIME_TYPE_ERR']='Only image file used to upload data, Invalid file uploaded !!';
$lang['FILE_UPLOAD_EMPTY_ERR']='Invalid file uploaded for \"Event Image\"  upload!!';
$lang['EVENT_SUCCESS']='Event Created Successfully !!!';
$lang['INVALID_EV_VID']='Invalid Youtube video URL provided !!!';
?>