<?php
$lang['UPD_ORG_PROF']="Update Organization Profile";
$lang['ORG_PROF']="Organization Profile";
?>