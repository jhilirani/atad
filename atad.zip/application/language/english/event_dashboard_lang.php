<?php
$lang['HOW_2_GO_LIVE']="How to make your event listing go live on Sponsarite";
$lang['Q_AC']='Quick Action';
$lang['UPL_PROF_PIC']='Upload a profile picture';
$lang['COMP_ORG_PROF']="Complete your organization profile";
$lang['UPL_EVENT']='Upload event';
$lang['UPDATE_BANK_INFO_MSG']='Enter your organization banking details to be eligible to receive sponsorship funds';
$lang['SPONS']='Sponsarite';
$lang['VID_RES']='Video Resource';
$lang['VID_RES_MSG']='In this video, we offer you important
tips to help you get started as an Event Organizer on Sponsarite';
$lang['ALL_UP_CO_EVENT']='Upcoming Events';
$lang['EVENT_NM']='Event Name';
$lang['CITY']='City';
$lang['STARTED_ON']='Started On';
$lang['END_ON']='Ends On';
$lang['DETAIL']='Details';
$lang['ALL_COMP_EVENTS']="Completed Events";
$lang['V_ALL_UP_CO_EVENT']="View all upcoming events";
$lang['V_ALL_COMP_EVENTS']="View all completed events";
$lang['P_FEEDBACK']="Post Feedback";
$lang['P_TESTM']="Post Testimonial";
$lang['P_TESTM_HEADING']="Your Testimonial Message";
$lang['TESTM_EMPTY_MSG']="Please enter the testimonial !!";
$lang['ENT_UR_TESTM']='Enter your testimonial';
$lang['UD']='Update';
$lang['No_SEC_EV']='There is no event for this section';
$lang['M_EV']='My Event/s';
$lang['SH']='Share';
?>