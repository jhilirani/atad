<?php
$lang['HEADING']="Testimonials";
?>