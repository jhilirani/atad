<?php
$lang['B_PAGE_HEAD']='Sponsarite Blog';
$lang['V_DET']='View Details';
?>