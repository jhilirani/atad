<?php
$lang['INV_REQEST_SUCC']='Invoice requested successfully';
?>