<?php
$lang['SUCC']='Brand Partnership objectives conditions accepted successfully !';
$lang['CANCEL']='Brand Partnership objectives conditions rejected successfully !';
?>