<section id="inner-headline">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<ul class="breadcrumb">
					<li><a href="<?php echo BASE_URL;?>"><i class="fa fa-home"></i></a><i class="icon-angle-right"></i></li>
					<li><a href="#" class="active"><?php echo $bread_crumb_data;?></a></li>
					<!--<i class="icon-angle-right"></i></li>
					<li class="active">Fullwidth</li>-->
				</ul>
			</div>
		</div>
	</div>
</section>