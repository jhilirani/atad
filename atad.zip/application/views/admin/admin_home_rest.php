</td>
  </tr>
</table>

    <!-- Body ended here-->
    </td>
  </tr>
  </table>
</body>
</html>
<script>
$(document).ready(function(){
    var headTitleData=$('.PageHeading').html();
    $('.PageHeading').html("");
    $(".textHadr").html(headTitleData);
    $(".textHadr").css("color","green");
});
</script>
