<tr>
    <td align="center" valign="middle" class="AdminFooterText"> &copy; All right resorved to Judhisthira Sahoo</td>
  </tr>
</table>

</body>
</html>
<script>
