<?php echo $html_heading;?><?php echo $header;?><?php echo $HomePageSlider;?>
<div id="maincontainer">
    <div class="testimonial_box">
        <div class="testimonial">
            <div class="sign_box" style="width: 450px; height: auto; margin: 0 auto; float: none;">		             
	    <h1>This page is under development.</h1>			
		<p><img src="<?php echo $SiteImagesURL;?>under_construction.png" alt="" border="0" width="423" height="185"/></p>
		<p><img src="<?php echo $SiteImagesURL;?>conts.jpg" alt="" border="0" width="450" height="400"/></p>
	</div>
        </div>
    </div>
</div>
<div class="clear"></div>
<?php echo $footer;?>