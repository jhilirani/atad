<body>
<div id="wrapper">
<div id="maintable">
<!--====================header start=========================-->
<div id="header">
<div class="header_top">
<div class="logo"><a href="#"><img src="<?php echo $SiteImagesURL?>logo.png" alt="" width="239" height="56" border="0"/></a></div>
<div class="header_right">
<h1>Toll Free : 1-800-929-0849 
    <span>Follow us on: 
        <a href="https://www.facebook.com/elearningportal"><img src="<?php echo $SiteImagesURL?>f.png" alt="https://www.facebook.com/elearningportal" width="19" height="21" border="0" align="absmiddle" /></a>&nbsp;&nbsp;
        <a href="https://twitter.com/learningportal1"><img src="<?php echo $SiteImagesURL?>t.png" alt="" width="19" height="22" border="0" align="absmiddle" /></a>&nbsp;&nbsp;
        <a href="https://www.linkedin.com/in/elearningportal"><img src="<?php echo $SiteImagesURL?>in.png" alt="https://www.linkedin.com/in/elearningportal" width="19" height="21" border="0" align="absmiddle" /></a>&nbsp;&nbsp;
        <a href="https://plus.google.com/u/0/112007375637080211779/posts"><img src="<?php echo $SiteImagesURL?>g.png" alt="https://plus.google.com/u/0/112007375637080211779/posts" width="19" height="22" border="0" align="absmiddle" /></a></span></h1>
<p style="float: right; width: 160px; margin: 8px 0; padding:0;"><img src="<?php echo $SiteImagesURL?>live.png" alt="" width="160" height="40" border="0"/></p>
</div>
</div>
<div class="clear"></div>
<div id="nav">
<ul>
<li><a href="<?php echo base_url();?>" class="here">Home</a></li>                 
<li><a href="<?php echo base_url();?>course">Courses</a></li>
<li><a href="<?php echo base_url();?>free-demo">Free Demo</a></li>
<li><a href="<?php echo base_url();?>pay-online">Pay Online </a></li>
<li><a href="<?php echo base_url();?>online-training"	>Online Training</a></li>
<li><a href="<?php echo base_url();?>testimonial">Testimonials</a></li>
<li><a href="<?php echo base_url();?>"contact-us>Contact Us</a></li>
</ul>
</ul>
</div>
</div>
<div class="clear"></div>