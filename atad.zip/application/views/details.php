<?php echo $html_heading;?><?php echo $header;?><?php echo $HomePageSlider;?>
<div id="maincontainer">
    <div class="testimonial_box">
        <div class="testimonial">
            <div><h1><?php echo $Details[0]->Title;?></h1></div>
            <div><?php echo $Details[0]->Description;?></div>
        </div>
    </div>
</div>
<div class="clear"></div>
<?php echo $footer;?>